public abstract class Shape {
    public abstract double area();

    public abstract double volume();
}

