public interface Loan {
    double issueLoan();
}